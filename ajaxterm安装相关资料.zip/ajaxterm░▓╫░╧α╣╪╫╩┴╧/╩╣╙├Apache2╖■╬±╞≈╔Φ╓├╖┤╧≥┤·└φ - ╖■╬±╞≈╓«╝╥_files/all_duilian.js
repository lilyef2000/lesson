document.write('<script type="text/javascript">var cpro_id = "u1489218";</script><script src="http://cpro.baidustatic.com/cpro/ui/f.js" type="text/javascript"></script>');
