/* generated javascript */
var skin = 'ubuntuchina';
var stylepath = '/skins';

/* MediaWiki:Common.js */
/* 此处的JavaScript将加载于所有用户每一个页面。 */

/* MediaWiki:Ubuntuchina.js */
